# Hotel Management System

A web-based hotel management system built with Flask, MySQL, and modern HTML/CSS.

## Features

- Hotel Management (Add, View, Edit, Delete)
- Room Management
- Customer Management
- Reservation System
- Payment Tracking

## Prerequisites

- Python 3.8 or higher
- MySQL Server
- pip (Python package manager)

## Setup Instructions

1. Clone the repository:
```bash
git clone <repository-url>
cd hotel_management_system
```

2. Create a virtual environment and activate it:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install the required packages:
```bash
pip install -r requirements.txt
```

4. Create a MySQL database:
```sql
CREATE DATABASE hotel_management;
```

5. Update the database configuration in `app.py`:
```python
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://username:password@localhost/hotel_management'
```

6. Initialize the database:
```bash
python
>>> from app import app, db
>>> with app.app_context():
...     db.create_all()
>>> exit()
```

7. Run the application:
```bash
python app.py
```

The application will be available at `http://localhost:5000`

## Project Structure

```
hotel_management_system/
├── static/
│   └── css/
│       └── style.css
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── hotels.html
│   └── add_hotel.html
├── app.py
├── requirements.txt
└── README.md
```

## Database Schema

```sql
CREATE TABLE Hotel (
    h_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    location TEXT NOT NULL
);

CREATE TABLE Room (
    r_id INTEGER PRIMARY KEY,
    h_id INTEGER,
    FOREIGN KEY (h_id) REFERENCES Hotel(h_id)
);

CREATE TABLE Customer (
    c_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    address TEXT NOT NULL
);

CREATE TABLE Payment (
    p_id INTEGER PRIMARY KEY,
    p_method TEXT NOT NULL,
    amount REAL NOT NULL,
    c_id INTEGER,
    FOREIGN KEY (c_id) REFERENCES Customer(c_id)
);

CREATE TABLE Reservation (
    res_id INTEGER PRIMARY KEY,
    r_id INTEGER,
    c_id INTEGER,
    date_of_reservation DATE,
    FOREIGN KEY (r_id) REFERENCES Room(r_id),
    FOREIGN KEY (c_id) REFERENCES Customer(c_id)
);
```

## Contributing

1. Fork the repository
2. Create a new branch
3. Make your changes
4. Submit a pull request

## License

This project is licensed under the MIT License. 