from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'default_secret_key')

# Database configuration
db_user = os.getenv('MYSQL_USER', 'root')
db_password = os.getenv('MYSQL_PASSWORD', 'your_password')
db_host = os.getenv('MYSQL_HOST', 'localhost')
db_name = os.getenv('MYSQL_DATABASE', 'hotel_management')

app.config['SQLALCHEMY_DATABASE_URI'] = f'mysql+pymysql://{db_user}:{db_password}@{db_host}/{db_name}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Models
class Hotel(db.Model):
    h_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(200), nullable=False)
    rooms = db.relationship('Room', backref='hotel', lazy=True)

class Room(db.Model):
    r_id = db.Column(db.Integer, primary_key=True)
    h_id = db.Column(db.Integer, db.ForeignKey('hotel.h_id'), nullable=False)
    room_number = db.Column(db.String(10), nullable=False)
    room_type = db.Column(db.String(50), nullable=False)
    price = db.Column(db.Float, nullable=False)
    reservations = db.relationship('Reservation', backref='room', lazy=True)

class Customer(db.Model):
    c_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    address = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    payments = db.relationship('Payment', backref='customer', lazy=True)
    reservations = db.relationship('Reservation', backref='customer', lazy=True)

class Payment(db.Model):
    p_id = db.Column(db.Integer, primary_key=True)
    c_id = db.Column(db.Integer, db.ForeignKey('customer.c_id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    p_method = db.Column(db.String(50), nullable=False)
    payment_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    status = db.Column(db.String(20), nullable=False, default='Full')  # 'Full' or 'Partial'
    reservation_id = db.Column(db.Integer, db.ForeignKey('reservation.res_id'), nullable=True)
    related_payment_id = db.Column(db.Integer, db.ForeignKey('payment.p_id'), nullable=True)
    related_payments = db.relationship('Payment', backref=db.backref('parent_payment', remote_side=[p_id]))

class Reservation(db.Model):
    res_id = db.Column(db.Integer, primary_key=True)
    r_id = db.Column(db.Integer, db.ForeignKey('room.r_id'), nullable=False)
    c_id = db.Column(db.Integer, db.ForeignKey('customer.c_id'), nullable=False)
    date_of_reservation = db.Column(db.Date, nullable=False, default=datetime.utcnow)
    check_in_date = db.Column(db.Date, nullable=False)
    check_out_date = db.Column(db.Date, nullable=False)
    payments = db.relationship('Payment', backref='reservation', lazy=True)

# Routes
@app.route('/')
def index():
    # Get some stats for the dashboard
    total_hotels = Hotel.query.count()
    total_rooms = Room.query.count()
    total_customers = Customer.query.count()
    total_reservations = Reservation.query.count()
    total_payments = Payment.query.count()
    total_revenue = db.session.query(db.func.sum(Payment.amount)).scalar() or 0

    return render_template('index.html', 
                         total_hotels=total_hotels,
                         total_rooms=total_rooms,
                         total_customers=total_customers,
                         total_reservations=total_reservations,
                         total_payments=total_payments,
                         total_revenue=total_revenue)

@app.route('/hotels')
def hotels():
    hotels = Hotel.query.all()
    return render_template('hotels.html', hotels=hotels)

@app.route('/add_hotel', methods=['GET', 'POST'])
def add_hotel():
    if request.method == 'POST':
        name = request.form['name']
        location = request.form['location']
        
        hotel = Hotel(name=name, location=location)
        db.session.add(hotel)
        db.session.commit()
        
        flash('Hotel added successfully!', 'success')
        return redirect(url_for('hotels'))
    
    return render_template('add_hotel.html')

@app.route('/rooms')
def rooms():
    rooms = Room.query.all()
    return render_template('rooms.html', rooms=rooms)

@app.route('/add_room', methods=['GET', 'POST'])
def add_room():
    if request.method == 'POST':
        hotel_id = request.form['hotel_id']
        room_number = request.form['room_number']
        room_type = request.form['room_type']
        price = request.form['price']
        
        room = Room(h_id=hotel_id, room_number=room_number, room_type=room_type, price=price)
        db.session.add(room)
        db.session.commit()
        
        flash('Room added successfully!', 'success')
        return redirect(url_for('rooms'))
    
    hotels = Hotel.query.all()
    return render_template('add_room.html', hotels=hotels)

@app.route('/customers')
def customers():
    customers = Customer.query.all()
    return render_template('customers.html', customers=customers)

@app.route('/add_customer', methods=['GET', 'POST'])
def add_customer():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        address = request.form['address']
        
        customer = Customer(name=name, email=email, phone=phone, address=address)
        db.session.add(customer)
        db.session.commit()
        
        flash('Customer added successfully!', 'success')
        return redirect(url_for('customers'))
    
    return render_template('add_customer.html')

@app.route('/reservations')
def reservations():
    reservations = Reservation.query.all()
    return render_template('reservations.html', reservations=reservations)

@app.route('/add_reservation', methods=['GET', 'POST'])
def add_reservation():
    if request.method == 'POST':
        customer_id = request.form['customer_id']
        room_id = request.form['room_id']
        check_in_date = datetime.strptime(request.form['check_in_date'], '%Y-%m-%d')
        check_out_date = datetime.strptime(request.form['check_out_date'], '%Y-%m-%d')
        
        reservation = Reservation(
            c_id=customer_id,
            r_id=room_id,
            check_in_date=check_in_date,
            check_out_date=check_out_date,
            date_of_reservation=datetime.utcnow()
        )
        db.session.add(reservation)
        db.session.commit()
        
        flash('Reservation added successfully!', 'success')
        return redirect(url_for('reservations'))
    
    customers = Customer.query.all()
    hotels = Hotel.query.all()
    rooms = Room.query.all()
    return render_template('add_reservation.html', customers=customers, hotels=hotels, rooms=rooms)

@app.route('/payments')
def payments():
    payments = Payment.query.order_by(Payment.payment_date.desc()).all()
    return render_template('payments.html', payments=payments)

@app.route('/add_payment', methods=['GET', 'POST'])
def add_payment():
    if request.method == 'POST':
        customer_id = request.form['customer_id']
        amount = request.form['amount']
        payment_method = request.form['payment_method']
        
        payment = Payment(
            c_id=customer_id,
            amount=amount,
            p_method=payment_method,
            payment_date=datetime.utcnow()
        )
        db.session.add(payment)
        db.session.commit()
        
        flash('Payment added successfully!', 'success')
        return redirect(url_for('payments'))
    
    customers = Customer.query.all()
    return render_template('add_payment.html', customers=customers)

# Edit routes for all models
@app.route('/edit_hotel/<int:hotel_id>', methods=['GET', 'POST'])
def edit_hotel(hotel_id):
    hotel = Hotel.query.get_or_404(hotel_id)
    if request.method == 'POST':
        hotel.name = request.form['name']
        hotel.location = request.form['location']
        db.session.commit()
        flash('Hotel updated successfully!', 'success')
        return redirect(url_for('hotels'))
    return render_template('edit_hotel.html', hotel=hotel)

@app.route('/edit_room/<int:room_id>', methods=['GET', 'POST'])
def edit_room(room_id):
    room = Room.query.get_or_404(room_id)
    if request.method == 'POST':
        room.h_id = request.form['hotel_id']
        room.room_number = request.form['room_number']
        room.room_type = request.form['room_type']
        room.price = request.form['price']
        db.session.commit()
        flash('Room updated successfully!', 'success')
        return redirect(url_for('rooms'))
    hotels = Hotel.query.all()
    return render_template('edit_room.html', room=room, hotels=hotels)

@app.route('/edit_customer/<int:customer_id>', methods=['GET', 'POST'])
def edit_customer(customer_id):
    customer = Customer.query.get_or_404(customer_id)
    if request.method == 'POST':
        customer.name = request.form['name']
        customer.email = request.form['email']
        customer.phone = request.form['phone']
        customer.address = request.form['address']
        db.session.commit()
        flash('Customer updated successfully!', 'success')
        return redirect(url_for('customers'))
    return render_template('edit_customer.html', customer=customer)

@app.route('/edit_reservation/<int:reservation_id>', methods=['GET', 'POST'])
def edit_reservation(reservation_id):
    reservation = Reservation.query.get_or_404(reservation_id)
    if request.method == 'POST':
        reservation.r_id = request.form['room_id']
        reservation.c_id = request.form['customer_id']
        reservation.check_in_date = datetime.strptime(request.form['check_in_date'], '%Y-%m-%d')
        reservation.check_out_date = datetime.strptime(request.form['check_out_date'], '%Y-%m-%d')
        db.session.commit()
        flash('Reservation updated successfully!', 'success')
        return redirect(url_for('reservations'))
    customers = Customer.query.all()
    rooms = Room.query.all()
    return render_template('edit_reservation.html', reservation=reservation, customers=customers, rooms=rooms)

@app.route('/edit_payment/<int:payment_id>', methods=['GET', 'POST'])
def edit_payment(payment_id):
    payment = Payment.query.get_or_404(payment_id)
    if request.method == 'POST':
        payment.c_id = request.form['customer_id']
        payment.amount = request.form['amount']
        payment.p_method = request.form['payment_method']
        payment.status = request.form['payment_status']
        
        # If this is a partial payment and there's no related payment yet
        if payment.status == 'Partial' and not payment.related_payment_id:
            # Create a new payment for the remaining amount
            new_payment = Payment(
                c_id=payment.c_id,
                amount=0,  # Will be filled in later
                p_method='Pending',
                status='Pending',
                reservation_id=payment.reservation_id,
                related_payment_id=payment.p_id
            )
            db.session.add(new_payment)
        
        db.session.commit()
        flash('Payment updated successfully!', 'success')
        return redirect(url_for('payments'))
    
    customers = Customer.query.all()
    return render_template('edit_payment.html', payment=payment, customers=customers)

# Delete routes
@app.route('/delete_hotel/<int:hotel_id>')
def delete_hotel(hotel_id):
    hotel = Hotel.query.get_or_404(hotel_id)
    db.session.delete(hotel)
    db.session.commit()
    flash('Hotel deleted successfully!', 'success')
    return redirect(url_for('hotels'))

@app.route('/delete_room/<int:room_id>')
def delete_room(room_id):
    room = Room.query.get_or_404(room_id)
    db.session.delete(room)
    db.session.commit()
    flash('Room deleted successfully!', 'success')
    return redirect(url_for('rooms'))

@app.route('/delete_customer/<int:customer_id>')
def delete_customer(customer_id):
    customer = Customer.query.get_or_404(customer_id)
    db.session.delete(customer)
    db.session.commit()
    flash('Customer deleted successfully!', 'success')
    return redirect(url_for('customers'))

@app.route('/delete_reservation/<int:reservation_id>')
def delete_reservation(reservation_id):
    reservation = Reservation.query.get_or_404(reservation_id)
    db.session.delete(reservation)
    db.session.commit()
    flash('Reservation deleted successfully!', 'success')
    return redirect(url_for('reservations'))

@app.route('/delete_payment/<int:payment_id>')
def delete_payment(payment_id):
    payment = Payment.query.get_or_404(payment_id)
    db.session.delete(payment)
    db.session.commit()
    flash('Payment deleted successfully!', 'success')
    return redirect(url_for('payments'))

if __name__ == '__main__':
    with app.app_context():
        # Drop all tables and recreate them
        db.drop_all()
        db.create_all()
        
        # Create a default hotel
        default_hotel = Hotel(name='Sample Hotel', location='Sample Location')
        db.session.add(default_hotel)
        db.session.commit()
        
    app.run(debug=True) 